﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace CA_Management
{
    class Lecturer:Person
    {
        public string LectID { get; set; }
        public List<string> LectCourse { get; set; }
        public Lecturer()
        {

        }
        public Lecturer(string fname, string sName, string email, string id, List<string> Course) : base(fname, sName, email)
        {
            this.LectID = id;
            this.LectCourse =Course;
        }

        private const string path = @"C:\Users\ldebi\Desktop\CA Management\Lecturer.txt";

        public static void SetLecturer(List<Lecturer> LecturerList)
        {
            StreamWriter textOut =
                new StreamWriter(
                new FileStream(path, FileMode.Create, FileAccess.Write));

            foreach (Lecturer s in LecturerList)
            {
                int i = s.LectCourse.Count;
                //MessageBox.Show(i.ToString());
                int y = 0;
                textOut.Write(s.LectID + ",");
                textOut.Write(s.firstName + ",");
                textOut.Write(s.surname + ",");
                textOut.Write(s.email + ",");

                foreach (string g in s.LectCourse)
                {
                    if (y != i - 1)
                        textOut.Write(g + ",");
                    else textOut.Write(g);
                    y++;
                }

                i = 0;
                i = s.LectCourse.Count;

                textOut.Write("\n" + "\n"); //This is here because its just easier to read when its nicely formatted.
            }


            textOut.Close();

        }

        public static List<Lecturer> GetLecturerData()
        {

            StreamReader textIn =
                new StreamReader(
                    new FileStream(path, FileMode.OpenOrCreate, FileAccess.Read));

            List<Lecturer> LecturerList = new List<Lecturer>();

            // read the data from the file and store it in the ArrayList
            while (textIn.Peek() != -1)
            {
                string row = textIn.ReadLine();
                string[] columns = row.Split(',');
                Lecturer newLecturer = new Lecturer();
                newLecturer.LectID = columns[0];
                newLecturer.firstName = columns[1];
                newLecturer.email = columns[2];

                string row2 = textIn.ReadLine();
                string[] columns2 = row2.Split(',');
                var CourseList = new List<string>();

                foreach (var f in columns2)
                {
                    if (f != "")
                        CourseList.Add(f);
                }

                newLecturer.LectCourse = CourseList;
                LecturerList.Add(newLecturer);

                string spacing = textIn.ReadLine();
                
            }

            textIn.Close();

            return LecturerList;

        }
    }
}
