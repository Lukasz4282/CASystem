﻿namespace CA_Management
{
    partial class frmStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkCompleted = new System.Windows.Forms.CheckBox();
            this.rbShowDue = new System.Windows.Forms.RadioButton();
            this.rbShowAll = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.cbChoose = new System.Windows.Forms.ComboBox();
            this.SelectedStudentLabel = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkCompleted);
            this.groupBox1.Controls.Add(this.rbShowDue);
            this.groupBox1.Controls.Add(this.rbShowAll);
            this.groupBox1.Font = new System.Drawing.Font("SimSun", 12F);
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(533, 115);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "FILTER";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // checkCompleted
            // 
            this.checkCompleted.AutoSize = true;
            this.checkCompleted.Location = new System.Drawing.Point(17, 80);
            this.checkCompleted.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.checkCompleted.Name = "checkCompleted";
            this.checkCompleted.Size = new System.Drawing.Size(171, 24);
            this.checkCompleted.TabIndex = 2;
            this.checkCompleted.Text = "HIDE COMPLETED";
            this.checkCompleted.UseVisualStyleBackColor = true;
            // 
            // rbShowDue
            // 
            this.rbShowDue.AutoSize = true;
            this.rbShowDue.Location = new System.Drawing.Point(233, 33);
            this.rbShowDue.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbShowDue.Name = "rbShowDue";
            this.rbShowDue.Size = new System.Drawing.Size(210, 24);
            this.rbShowDue.TabIndex = 1;
            this.rbShowDue.TabStop = true;
            this.rbShowDue.Text = "SHOW DUE THIS WEEK";
            this.rbShowDue.UseVisualStyleBackColor = true;
            // 
            // rbShowAll
            // 
            this.rbShowAll.AutoSize = true;
            this.rbShowAll.Location = new System.Drawing.Point(19, 33);
            this.rbShowAll.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbShowAll.Name = "rbShowAll";
            this.rbShowAll.Size = new System.Drawing.Size(150, 24);
            this.rbShowAll.TabIndex = 0;
            this.rbShowAll.TabStop = true;
            this.rbShowAll.Text = "SHOW ALL CA ";
            this.rbShowAll.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("SimSun", 11F);
            this.label1.Location = new System.Drawing.Point(47, 149);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(139, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "CHOOSE MODULE";
            // 
            // cbChoose
            // 
            this.cbChoose.Font = new System.Drawing.Font("SimSun", 11F);
            this.cbChoose.FormattingEnabled = true;
            this.cbChoose.Items.AddRange(new object[] {
            "SHOW ALL"});
            this.cbChoose.Location = new System.Drawing.Point(247, 149);
            this.cbChoose.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbChoose.Name = "cbChoose";
            this.cbChoose.Size = new System.Drawing.Size(265, 26);
            this.cbChoose.TabIndex = 2;
            // 
            // SelectedStudentLabel
            // 
            this.SelectedStudentLabel.AutoSize = true;
            this.SelectedStudentLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectedStudentLabel.Location = new System.Drawing.Point(694, 13);
            this.SelectedStudentLabel.Name = "SelectedStudentLabel";
            this.SelectedStudentLabel.Size = new System.Drawing.Size(168, 25);
            this.SelectedStudentLabel.TabIndex = 5;
            this.SelectedStudentLabel.Text = "Student Selected:";
            // 
            // frmStudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1181, 533);
            this.Controls.Add(this.SelectedStudentLabel);
            this.Controls.Add(this.cbChoose);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmStudent";
            this.Text = "STUDENT CA";
            this.Load += new System.EventHandler(this.frmStudent_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkCompleted;
        private System.Windows.Forms.RadioButton rbShowDue;
        private System.Windows.Forms.RadioButton rbShowAll;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbChoose;
        private System.Windows.Forms.Label SelectedStudentLabel;
    }
}