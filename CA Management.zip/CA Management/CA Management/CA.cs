﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace CA_Management
{

    class CA
    {

        private const string path = @"C:\Users\ldebi\Desktop\CA Management\CA.txt";

        public String CAID { get; set; }
        public String CAName { get; set; }
        public String DueDate { get; set; }
        public double Percentage { get; set; }

        public CA()
        {
            this.CAID = Guid.NewGuid().ToString("N");
            this.CAName = "";
            this.DueDate = "";
            this.Percentage = 0;
        }

        public CA(String CAName, String DueDate, double Percentage)
        {
            this.CAID = Guid.NewGuid().ToString("N");
            this.CAName = CAName;
            this.DueDate = DueDate;
            this.Percentage = Percentage;
        }

        public static void SetCA(List<CA> CAList)
        {
            StreamWriter textOut =
                new StreamWriter(
                new FileStream(path, FileMode.Create, FileAccess.Write));

            foreach (CA s in CAList)
            {
                textOut.Write(s.CAID + ",");
                textOut.Write(s.CAName + ",");
                textOut.Write(s.DueDate + ",");
                textOut.Write(s.Percentage + ",");

                textOut.Write("\n" + "\n"); //This is here because its just easier to read when its nicely formatted.
            }


            textOut.Close();

        }

        public static List<CA> GetCAData()
        {

            StreamReader textIn =
                new StreamReader(
                    new FileStream(path, FileMode.OpenOrCreate, FileAccess.Read));

            List<CA> CAList = new List<CA>();

            // read the data from the file and store it in the ArrayList
            while (textIn.Peek() != -1)
            {
                string row = textIn.ReadLine();
                string[] columns = row.Split(',');
                CA newCA = new CA();
                newCA.CAID = columns[0];
                newCA.CAName = columns[1];
                newCA.DueDate = columns[2];
                newCA.Percentage = Convert.ToDouble(columns[3]);

                CAList.Add(newCA);

                string spacing = textIn.ReadLine();
            }

            textIn.Close();

            return CAList;

        }
    }
}
