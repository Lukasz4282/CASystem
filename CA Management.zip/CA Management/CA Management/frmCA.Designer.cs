﻿namespace CA_Management
{
    partial class frmCA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.cbCAOptions = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbModName = new System.Windows.Forms.TextBox();
            this.tbCAName = new System.Windows.Forms.TextBox();
            this.numPercentage = new System.Windows.Forms.NumericUpDown();
            this.dtDueDate = new System.Windows.Forms.DateTimePicker();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnViewCA = new System.Windows.Forms.Button();
            this.btnSubmitCA = new System.Windows.Forms.Button();
            this.LectCoursesList = new System.Windows.Forms.ListBox();
            this.lectCourses = new System.Windows.Forms.Label();
            this.LectModulesList = new System.Windows.Forms.ListBox();
            this.LectModsInCourse = new System.Windows.Forms.Label();
            this.selectedLecturer = new System.Windows.Forms.Label();
            this.LectCAInModule = new System.Windows.Forms.Label();
            this.LectCAList = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.numPercentage)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("SimSun", 12F);
            this.label1.Location = new System.Drawing.Point(81, 47);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(159, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "SELECT OPTION: ";
            // 
            // cbCAOptions
            // 
            this.cbCAOptions.Font = new System.Drawing.Font("SimSun", 12F);
            this.cbCAOptions.FormattingEnabled = true;
            this.cbCAOptions.Items.AddRange(new object[] {
            "ADD CA",
            "CHANGE DUE DATE",
            "DELETE CA"});
            this.cbCAOptions.Location = new System.Drawing.Point(285, 43);
            this.cbCAOptions.Margin = new System.Windows.Forms.Padding(4);
            this.cbCAOptions.Name = "cbCAOptions";
            this.cbCAOptions.Size = new System.Drawing.Size(265, 28);
            this.cbCAOptions.TabIndex = 1;
            this.cbCAOptions.SelectedIndexChanged += new System.EventHandler(this.cbCAOptions_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("SimSun", 12F);
            this.label2.Location = new System.Drawing.Point(113, 121);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "MODULE NAME:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("SimSun", 12F);
            this.label3.Location = new System.Drawing.Point(156, 195);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "CA NAME:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("SimSun", 12F);
            this.label4.Location = new System.Drawing.Point(145, 265);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "DUE DATE:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("SimSun", 12F);
            this.label5.Location = new System.Drawing.Point(49, 335);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(189, 20);
            this.label5.TabIndex = 5;
            this.label5.Text = "TOTAL PERCENTAGE: ";
            // 
            // tbModName
            // 
            this.tbModName.Font = new System.Drawing.Font("SimSun", 12F);
            this.tbModName.Location = new System.Drawing.Point(285, 121);
            this.tbModName.Margin = new System.Windows.Forms.Padding(4);
            this.tbModName.Name = "tbModName";
            this.tbModName.Size = new System.Drawing.Size(265, 30);
            this.tbModName.TabIndex = 6;
            // 
            // tbCAName
            // 
            this.tbCAName.Font = new System.Drawing.Font("SimSun", 12F);
            this.tbCAName.Location = new System.Drawing.Point(285, 195);
            this.tbCAName.Margin = new System.Windows.Forms.Padding(4);
            this.tbCAName.Name = "tbCAName";
            this.tbCAName.Size = new System.Drawing.Size(265, 30);
            this.tbCAName.TabIndex = 7;
            // 
            // numPercentage
            // 
            this.numPercentage.Font = new System.Drawing.Font("SimSun", 12F);
            this.numPercentage.Location = new System.Drawing.Point(285, 332);
            this.numPercentage.Margin = new System.Windows.Forms.Padding(4);
            this.numPercentage.Name = "numPercentage";
            this.numPercentage.Size = new System.Drawing.Size(267, 30);
            this.numPercentage.TabIndex = 8;
            // 
            // dtDueDate
            // 
            this.dtDueDate.CalendarFont = new System.Drawing.Font("SimSun", 12F);
            this.dtDueDate.Location = new System.Drawing.Point(285, 265);
            this.dtDueDate.Margin = new System.Windows.Forms.Padding(4);
            this.dtDueDate.Name = "dtDueDate";
            this.dtDueDate.Size = new System.Drawing.Size(265, 22);
            this.dtDueDate.TabIndex = 9;
            // 
            // btnBack
            // 
            this.btnBack.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnBack.Font = new System.Drawing.Font("SimSun", 12F);
            this.btnBack.Location = new System.Drawing.Point(53, 444);
            this.btnBack.Margin = new System.Windows.Forms.Padding(4);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(100, 31);
            this.btnBack.TabIndex = 10;
            this.btnBack.Text = "BACK";
            this.btnBack.UseVisualStyleBackColor = true;
            // 
            // btnViewCA
            // 
            this.btnViewCA.Font = new System.Drawing.Font("SimSun", 12F);
            this.btnViewCA.Location = new System.Drawing.Point(225, 444);
            this.btnViewCA.Margin = new System.Windows.Forms.Padding(4);
            this.btnViewCA.Name = "btnViewCA";
            this.btnViewCA.Size = new System.Drawing.Size(127, 31);
            this.btnViewCA.TabIndex = 11;
            this.btnViewCA.Text = "VIEW CA";
            this.btnViewCA.UseVisualStyleBackColor = true;
            // 
            // btnSubmitCA
            // 
            this.btnSubmitCA.Font = new System.Drawing.Font("SimSun", 12F);
            this.btnSubmitCA.Location = new System.Drawing.Point(403, 444);
            this.btnSubmitCA.Margin = new System.Windows.Forms.Padding(4);
            this.btnSubmitCA.Name = "btnSubmitCA";
            this.btnSubmitCA.Size = new System.Drawing.Size(149, 31);
            this.btnSubmitCA.TabIndex = 12;
            this.btnSubmitCA.Text = "ADD CA";
            this.btnSubmitCA.UseVisualStyleBackColor = true;
            this.btnSubmitCA.Click += new System.EventHandler(this.btnSubmitCA_Click);
            // 
            // LectCoursesList
            // 
            this.LectCoursesList.FormattingEnabled = true;
            this.LectCoursesList.ItemHeight = 16;
            this.LectCoursesList.Location = new System.Drawing.Point(595, 44);
            this.LectCoursesList.Name = "LectCoursesList";
            this.LectCoursesList.Size = new System.Drawing.Size(240, 196);
            this.LectCoursesList.TabIndex = 13;
            this.LectCoursesList.SelectedIndexChanged += new System.EventHandler(this.LectCoursesList_SelectedIndexChanged);
            // 
            // lectCourses
            // 
            this.lectCourses.AutoSize = true;
            this.lectCourses.Location = new System.Drawing.Point(648, 23);
            this.lectCourses.Name = "lectCourses";
            this.lectCourses.Size = new System.Drawing.Size(127, 17);
            this.lectCourses.TabIndex = 14;
            this.lectCourses.Text = "Lecturer\'s Courses";
            // 
            // LectModulesList
            // 
            this.LectModulesList.FormattingEnabled = true;
            this.LectModulesList.ItemHeight = 16;
            this.LectModulesList.Location = new System.Drawing.Point(882, 44);
            this.LectModulesList.Name = "LectModulesList";
            this.LectModulesList.Size = new System.Drawing.Size(240, 196);
            this.LectModulesList.TabIndex = 15;
            this.LectModulesList.SelectedIndexChanged += new System.EventHandler(this.LectModulesList_SelectedIndexChanged);
            // 
            // LectModsInCourse
            // 
            this.LectModsInCourse.AutoSize = true;
            this.LectModsInCourse.Location = new System.Drawing.Point(936, 23);
            this.LectModsInCourse.Name = "LectModsInCourse";
            this.LectModsInCourse.Size = new System.Drawing.Size(126, 17);
            this.LectModsInCourse.TabIndex = 16;
            this.LectModsInCourse.Text = "Module\'s in course";
            // 
            // selectedLecturer
            // 
            this.selectedLecturer.AutoSize = true;
            this.selectedLecturer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectedLecturer.Location = new System.Drawing.Point(590, 265);
            this.selectedLecturer.Name = "selectedLecturer";
            this.selectedLecturer.Size = new System.Drawing.Size(171, 25);
            this.selectedLecturer.TabIndex = 17;
            this.selectedLecturer.Text = "Selected Lecturer:";
            // 
            // LectCAInModule
            // 
            this.LectCAInModule.AutoSize = true;
            this.LectCAInModule.Location = new System.Drawing.Point(1235, 23);
            this.LectCAInModule.Name = "LectCAInModule";
            this.LectCAInModule.Size = new System.Drawing.Size(91, 17);
            this.LectCAInModule.TabIndex = 19;
            this.LectCAInModule.Text = "CA in Module";
            // 
            // LectCAList
            // 
            this.LectCAList.FormattingEnabled = true;
            this.LectCAList.ItemHeight = 16;
            this.LectCAList.Location = new System.Drawing.Point(1162, 43);
            this.LectCAList.Name = "LectCAList";
            this.LectCAList.Size = new System.Drawing.Size(240, 196);
            this.LectCAList.TabIndex = 18;
            this.LectCAList.SelectedIndexChanged += new System.EventHandler(this.LectCAList_SelectedIndexChanged);
            // 
            // frmCA
            // 
            this.AcceptButton = this.btnSubmitCA;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnBack;
            this.ClientSize = new System.Drawing.Size(1414, 532);
            this.Controls.Add(this.LectCAInModule);
            this.Controls.Add(this.LectCAList);
            this.Controls.Add(this.selectedLecturer);
            this.Controls.Add(this.LectModsInCourse);
            this.Controls.Add(this.LectModulesList);
            this.Controls.Add(this.lectCourses);
            this.Controls.Add(this.LectCoursesList);
            this.Controls.Add(this.btnSubmitCA);
            this.Controls.Add(this.btnViewCA);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.dtDueDate);
            this.Controls.Add(this.numPercentage);
            this.Controls.Add(this.tbCAName);
            this.Controls.Add(this.tbModName);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbCAOptions);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmCA";
            this.Text = "CA MANAGER";
            this.Load += new System.EventHandler(this.frmCA_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numPercentage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbCAOptions;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbModName;
        private System.Windows.Forms.TextBox tbCAName;
        private System.Windows.Forms.NumericUpDown numPercentage;
        private System.Windows.Forms.DateTimePicker dtDueDate;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnViewCA;
        private System.Windows.Forms.Button btnSubmitCA;
        private System.Windows.Forms.ListBox LectCoursesList;
        private System.Windows.Forms.Label lectCourses;
        private System.Windows.Forms.ListBox LectModulesList;
        private System.Windows.Forms.Label LectModsInCourse;
        private System.Windows.Forms.Label selectedLecturer;
        private System.Windows.Forms.Label LectCAInModule;
        private System.Windows.Forms.ListBox LectCAList;
    }
}