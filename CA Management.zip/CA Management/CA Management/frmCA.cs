﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CA_Management
{
    public partial class frmCA : Form
    {

        List<Lecturer> LecturerList = Lecturer.GetLecturerData();
        Lecturer SelectedLecturer = new Lecturer();
       
        List<Module> ModuleList = Module.GetModuleData();
        Module SelectedModule = new Module();

        List<CA> CAList = CA.GetCAData();

        public frmCA()
        {
            InitializeComponent();
            cbCAOptions.SelectedIndex = 0;
        }

        private void frmCA_Load(object sender, EventArgs e)
        {
            selectedLecturer.Text = frmMain.SelectedLecturerID;

            foreach (Lecturer r in LecturerList)
            {
                if (r.LectID == selectedLecturer.Text)
                {
                    SelectedLecturer = r;
                }
            }

            selectedLecturer.Text = String.Concat("Selected Lecturer: ", frmMain.SelectedLecturerID);

            foreach (string q in SelectedLecturer.LectCourse) //Foreach string in each weeks list of CA
            {
                if (!LectCoursesList.Items.Contains(q)) //Populating the menu
                {
                    LectCoursesList.Items.Add(q);
                }
            }
           

            

        }

        private void cbCAOptions_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cbCAOptions.SelectedIndex==0)
            {
                btnSubmitCA.Text = "ADD CA";
            }
            else if (cbCAOptions.SelectedIndex == 1)
            {
                btnSubmitCA.Text = "EDIT CA";
            }
            else
            {
                btnSubmitCA.Text = "DELETE CA";
                dtDueDate.Enabled = false;
                numPercentage.Enabled = false;
            }
        }

        private void btnSubmitCA_Click(object sender, EventArgs e)
        {

        }

        private void LectCoursesList_SelectedIndexChanged(object sender, EventArgs e)
        {
            LectModulesList.Items.Clear();
            string selected = LectCoursesList.SelectedItem.ToString();

            foreach (var a in ModuleList)
            {
                if (a.ModuleCode == selected && a.Lecturer == frmMain.SelectedLecturerID)
                {
                    LectModulesList.Items.Add(a.ModuleName);
                }
            }

        }

        private void LectCAList_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void LectModulesList_SelectedIndexChanged(object sender, EventArgs e)
        {
           
            LectCAList.Items.Clear();
            string selected = LectModulesList.SelectedItem.ToString();

            foreach (var b in CAList)
            {
                foreach (var a in ModuleList)
                {
                   
                    if (a.ModuleName == selected && a.Lecturer == frmMain.SelectedLecturerID)
                    {
                        foreach (var c in a.ModuleCA)
                        {
                            if (b.CAID == c)
                                LectCAList.Items.Add(b.CAName);
                        }
                    }
                }
            }
        }
    }
}
