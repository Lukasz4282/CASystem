﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CA_Management
{
    public partial class frmStudent : Form
    {


        List<Student> StudentList = Student.GetStudentData();
        List<String> CAList = new List<String>();
        Student SelectedStudent = new Student();

        public frmStudent()
        {
            InitializeComponent();

               
            
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void frmStudent_Load(object sender, EventArgs e)
        {
            SelectedStudentLabel.Text = frmMain.SelectedStudentKNumber;

            foreach(Student r in StudentList)
            {
                if (r.KNum == SelectedStudentLabel.Text)
                {
                    SelectedStudent = r;
                }
            }

            SelectedStudentLabel.Text = String.Concat("Selected Student: ", frmMain.SelectedStudentKNumber);

            foreach (string q in SelectedStudent.StudentModule) //Foreach string in each weeks list of CA
                {
                    if (!cbChoose.Items.Contains(q)) //Populating the menu
                    {
                        cbChoose.Items.Add(q);
                        CAList.Add(q);
                    }
                }
            cbChoose.SelectedIndex = 0;
            
        }
    }
}
