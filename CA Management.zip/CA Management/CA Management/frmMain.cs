﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CA_Management
{
    public partial class frmMain : Form
    {

        List<Student> StudentList = Student.GetStudentData();
        List<Lecturer> LecturerList = Lecturer.GetLecturerData();
        List<String> CAList = new List<String>();
        Student SelectedStudent = new Student();

        public static string SelectedStudentKNumber = "DEFAULT_VALUE";
        public static string SelectedLecturerID = "DEFAULT_VALUE";

        public frmMain()
        {
            SelectedStudent = StudentList[0];
            InitializeComponent();
            cbSelect.Items.Clear();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (rdLecturer.Checked)
            {
                SelectedLecturerID = cbSelect.SelectedItem.ToString();
                Form newForm = new frmLect();
                newForm.Show();
            }

            else if (rdStudent.Checked)
            {
                SelectedStudentKNumber = cbSelect.SelectedItem.ToString();
                Form newForm = new frmStudent();
                newForm.Show();
            }
            else
            {
                MessageBox.Show("Please select either Student Option Or Lecturer Option");
            }
        }

        private void rdStudent_CheckedChanged(object sender, EventArgs e)
        {
            cbSelect.Items.Clear();

            foreach (Student c in StudentList) //Foreach week in the list
            {
                if (!cbSelect.Items.Contains(c.KNum)) //Populating the menu
                {
                    cbSelect.Items.Add(c.KNum);
                }
            }

            cbSelect.SelectedIndex = 0;
        }

        private void rdLecturer_CheckedChanged(object sender, EventArgs e)
        {
            cbSelect.Items.Clear();
            foreach (Lecturer c in LecturerList) //Foreach week in the list
            {
                if (!cbSelect.Items.Contains(c.LectID)) //Populating the menu
                {
                    cbSelect.Items.Add(c.LectID);
                }
            }

            cbSelect.SelectedIndex = 0;
        }

        private void cbSelect_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
