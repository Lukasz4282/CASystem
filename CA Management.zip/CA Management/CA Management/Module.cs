﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace CA_Management
{
    public class Module
    {
        public string Lecturer { get; set; }
        public string ModuleCode { get; set; }
        public string ModuleName { get; set; }
        public List<string> ModuleCA { get; set; }

        public Module()
        {

        }
        public Module(string lect, string code, string name, List<string> CA)
        {
            this.Lecturer = lect;
            this.ModuleCode = code;
            this.ModuleName = name;
            this.ModuleCA = CA;
            
        }

        private const string path = @"C:\Users\ldebi\Desktop\CA Management\Module.txt";

        public static void SetModule(List<Module> ModuleList)
        {
            StreamWriter textOut =
                new StreamWriter(
                new FileStream(path, FileMode.Create, FileAccess.Write));

            foreach (Module s in ModuleList)
            {
                int i = s.ModuleCA.Count;
                //MessageBox.Show(i.ToString());
                int y = 0;
                textOut.Write(s.Lecturer + ",");
                textOut.Write(s.ModuleCode + ",");
                textOut.WriteLine(s.ModuleName);

                foreach (var g in s.ModuleCA)
                {
                    if (y != i - 1)
                        textOut.Write(g + ",");
                    else textOut.Write(g);
                    y++;
                }

                i = 0;
                i = s.ModuleCA.Count;

                textOut.Write("\n" + "\n"); //This is here because its just easier to read when its nicely formatted.
            }


            textOut.Close();

        }

        public static List<Module> GetModuleData()
        {

            StreamReader textIn =
                new StreamReader(
                    new FileStream(path, FileMode.OpenOrCreate, FileAccess.Read));

            List<Module> ModuleList = new List<Module>();

            // read the data from the file and store it in the ArrayList
            while (textIn.Peek() != -1)
            {
                string row = textIn.ReadLine();
                string[] columns = row.Split(',');
                Module newModule = new Module();
                newModule.Lecturer = columns[0];
                newModule.ModuleCode = columns[1];
                newModule.ModuleName = columns[2];

                var row2 = textIn.ReadLine();
                string[] columns2 = row2.Split(',');
                var CourseList = new List<string>();

                foreach (var f in columns2)
                {
                    if (f != "")
                        CourseList.Add(f);
                }

                newModule.ModuleCA = CourseList;
                ModuleList.Add(newModule);

                string spacing = textIn.ReadLine();
            }

            textIn.Close();

            return ModuleList;

        }


    }
}
