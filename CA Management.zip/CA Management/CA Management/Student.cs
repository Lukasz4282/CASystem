﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace CA_Management
{
    class Student : Person
    {
        public string KNum { get; set; }
        public string Course { get; set; }
        public List<string> StudentModule { get; set; }

        public Student()
        {

        }
        public Student(string fname, string sName, string kNum, string email, string Course, List<string> Mcode) : base(fname, sName, email)
        {
            this.KNum = kNum;
            this.Course = Course;
            this.StudentModule = Mcode;
        }

        private const string path = @"C:\Users\ldebi\Desktop\CA Management\Student.txt";

        public static void SetStudent(List<Student> StudentList)
        {
            StreamWriter textOut =
                new StreamWriter(
                new FileStream(path, FileMode.Create, FileAccess.Write));

            foreach (Student s in StudentList)
            {
                int i = s.StudentModule.Count;
                //MessageBox.Show(i.ToString());
                int y = 0;
                textOut.Write(s.firstName + ",");
                textOut.Write(s.surname + ",");
                textOut.Write(s.KNum + ",");
                textOut.Write(s.email + ",");
                textOut.WriteLine(s.Course);

                foreach (string g in s.StudentModule)
                {
                    if (y != i - 1)
                        textOut.Write(g + ","); 
                    else textOut.Write(g);
                    y++;
                }

                i = 0;
                i = s.StudentModule.Count;

                textOut.Write("\n" + "\n"); //This is here because its just easier to read when its nicely formatted.
            }


            textOut.Close();

        }

        public static List<Student> GetStudentData()
        {
            
            StreamReader textIn =
                new StreamReader(
                    new FileStream(path, FileMode.OpenOrCreate, FileAccess.Read));

            List<Student> StudentList = new List<Student>();

            // read the data from the file and store it in the ArrayList
            while (textIn.Peek() != -1)
            {
                string row = textIn.ReadLine();
                string[] columns = row.Split(',');
                Student newStudent = new Student();
                newStudent.firstName = columns[0];
                newStudent.surname = columns[1];
                newStudent.KNum = columns[2];
                newStudent.email = columns[3];
                newStudent.Course = columns[4];

                string row2 = textIn.ReadLine();
                string[] columns2 = row2.Split(',');
                var modCodeList = new List<string>();
            
                    foreach (var f in columns2)
                    {
                    if (f != "")
                         modCodeList.Add(f);
                    }

                newStudent.StudentModule = modCodeList;
                StudentList.Add(newStudent);

                string spacing = textIn.ReadLine();
            }

            textIn.Close();

            return StudentList;
        
        }
    }

}
